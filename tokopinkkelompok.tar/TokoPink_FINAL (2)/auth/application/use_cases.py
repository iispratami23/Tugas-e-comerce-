class CartUseCase:
    def _init_(self, cart_repo, cart_item_repo):
        self.cart_repo = cart_repo
        self.cart_item_repo = cart_item_repo

    # 1. Lihat keranjang
    def view_cart(self, user_id):
        cart = self.cart_repo.get_cart_by_user(user_id)

        if not cart:
            return {
                "items": [],
                "total_produk": 0,
                "total_harga": 0
            }

        return {
            "items": cart.items,
            "total_produk": len(cart.items),
            "total_harga": cart.total_harga
        }

    # 2. Tambah produk ke keranjang
    def add_to_cart(self, user_id, product, quantity):
        cart = self.cart_repo.get_cart_by_user(user_id)

        if not cart:
            cart = self.cart_repo.create_cart(user_id)

        self.cart_item_repo.add_item(
            cart=cart,
            product=product,
            quantity=quantity
        )

        self.cart_repo.update_total(cart.id)
        return cart

    # 3. Ubah jumlah produk
    def update_quantity(self, user_id, cart_item_id, quantity):
        cart = self.cart_repo.get_cart_by_user(user_id)

        if not cart:
            raise ValueError("Keranjang tidak ditemukan")

        self.cart_item_repo.update_qty(
            cart=cart,
            cart_item_id=cart_item_id,
            quantity=quantity
        )

        self.cart_repo.update_total(cart.id)
        return cart

    # 4. Hapus produk dari keranjang
    def remove_item(self, user_id, cart_item_id):
        cart = self.cart_repo.get_cart_by_user(user_id)

        if not cart:
            raise ValueError("Keranjang tidak ditemukan")

        self.cart_item_repo.delete_item(
            cart=cart,
            cart_item_id=cart_item_id
        )

        self.cart_repo.update_total(cart.id)
        return cart

    # 5. Checkout
    def checkout(self, user_id):
        cart = self.cart_repo.get_cart_by_user(user_id)

        if not cart or not cart.items:
            raise ValueError("Keranjang kosong")

        result = {
            "total_produk": len(cart.items),
            "total_harga": cart.total_harga,
            "status": "Checkout berhasil"
        }

        # kosongkan keranjang
        cart.items = []
        cart.total_harga = 0

        return result