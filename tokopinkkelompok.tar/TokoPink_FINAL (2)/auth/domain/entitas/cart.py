class Cart:
    def _init_(self, id: int, user_id: int):
        self.id = id
        self.user_id = user_id
        self.items = []
        self.total_harga = 0

    def tambah_item(self, cart_item):
        self.items.append(cart_item)
        self.hitung_total()

    def hapus_item(self, cart_item_id: int):
        self.items = [item for item in self.items if item.id != cart_item_id]
        self.hitung_total()

    def hitung_total(self):
        self.total_harga = sum(item.item_total for item in self.items)

    def _repr_(self):
        return f"Cart(user_id={self.user_id}, total={self.total_harga})"