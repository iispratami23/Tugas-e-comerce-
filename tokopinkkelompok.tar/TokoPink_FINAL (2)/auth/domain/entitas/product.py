class Product:
    def _init_(self, id: int, nama: str, harga: float, stok: int, gambar: str):
        self.id = id
        self.nama = nama
        self.harga = harga
        self.stok = stok
        self.gambar = gambar

    def kurangi_stok(self, jumlah: int):
        if jumlah > self.stok:
            raise ValueError("Stok tidak mencukupi")
        self.stok -= jumlah

    def _repr_(self):
        return f"Product(id={self.id}, nama={self.nama}, harga={self.harga})"