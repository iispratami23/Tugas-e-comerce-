class CartItem:
    def _init_(self, id: int, product, quantity: int):
        self.id = id
        self.product = product
        self.quantity = quantity
        self.item_total = self.hitung_total()

    def hitung_total(self):
        return self.product.harga * self.quantity

    def update_quantity(self, quantity: int):
        self.quantity = quantity
        self.item_total = self.hitung_total()

    def _repr_(self):
        return f"CartItem(product={self.product.nama}, qty={self.quantity})"