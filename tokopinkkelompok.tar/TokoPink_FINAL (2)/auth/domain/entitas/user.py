class User:
    def _init_(self, id: int, nama: str, email: str, password: str):
        self.id = id
        self.nama = nama
        self.email = email
        self.password = password

    def _repr_(self):
        return f"User(id={self.id}, nama={self.nama}, email={self.email})"