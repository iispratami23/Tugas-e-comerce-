from auth.domain.entitas.cart import Cart

class CartRepository:
    def __init__(self):
        # Simpan cart di memory
        self.carts = []
        self._id_counter = 1

    def get_cart_by_user(self, user_id: int):
        for cart in self.carts:
            if cart.user_id == user_id:
                return cart
        return None

    def create_cart(self, user_id: int):
        cart = Cart(
            id=self._id_counter,
            user_id=user_id
        )
        self._id_counter += 1
        self.carts.append(cart)
        return cart

    def update_total(self, cart_id: int):
        for cart in self.carts:
            if cart.id == cart_id:
                cart.hitung_total()
                return cart.total_harga
        raise ValueError("Cart tidak ditemukan")