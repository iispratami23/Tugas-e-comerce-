from domain.entitas.cart_item import CartItem

class CartItemRepository:
    def _init_(self):
        self._id_counter = 1

    def add_item(self, cart, product, quantity: int):
        # cek apakah produk sudah ada di cart
        for item in cart.items:
            if item.product.id == product.id:
                item.update_quantity(item.quantity + quantity)
                cart.hitung_total()
                return item

        cart_item = CartItem(
            id=self._id_counter,
            product=product,
            quantity=quantity
        )
        self._id_counter += 1

        cart.items.append(cart_item)
        cart.hitung_total()
        return cart_item

    def update_qty(self, cart, cart_item_id: int, quantity: int):
        for item in cart.items:
            if item.id == cart_item_id:
                item.update_quantity(quantity)
                cart.hitung_total()
                return item
        raise ValueError("Item tidak ditemukan")

    def delete_item(self, cart, cart_item_id: int):
        cart.items = [
            item for item in cart.items if item.id != cart_item_id
        ]
        cart.hitung_total()

    def get_item_by_cart(self, cart):
        return cart.items