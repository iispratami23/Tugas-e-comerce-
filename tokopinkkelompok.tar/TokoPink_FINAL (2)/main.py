from flask import Flask, render_template, request, redirect, url_for, session, flash
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = "secretkey123"
app.config['UPLOAD_FOLDER'] = os.path.join('static', 'uploads')

# Data user dalam memory (untuk demo)
users = {}

# Data produk contoh (bisa tambah lewat add_product)
products = []

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ['png','jpg','jpeg','gif']

# Fungsi helper untuk mengonversi keranjang lama (list) ke dict
def get_cart():
    cart = session.get('cart', {})
    # Jika cart adalah list (versi lama), konversi ke dict dengan key str
    if isinstance(cart, list):
        new_cart = {}
        for product_id in cart:
            key = str(product_id)
            if key in new_cart:
                new_cart[key] += 1
            else:
                new_cart[key] = 1
        session['cart'] = new_cart
        return new_cart
    # Jika sudah dict, pastikan semua key adalah string untuk konsistensi
    if isinstance(cart, dict):
        new_cart = {}
        for k, v in cart.items():
            new_cart[str(k)] = v
        session['cart'] = new_cart
        return new_cart
    return cart

def save_cart(cart):
    # Simpan cart ke session dengan key bertipe string
    new_cart = {str(k): v for k, v in cart.items()}
    session['cart'] = new_cart

@app.route('/')
def index():
    if 'email' in session:
        return redirect(url_for('katalog'))
    return redirect(url_for('login'))

# REGISTER
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        if email in users:
            flash("Email sudah terdaftar!", "danger")
            return redirect(url_for('register'))

        users[email] = {"password": password}
        flash("Registrasi berhasil. Silakan login.", "success")
        return redirect(url_for('login'))
    return render_template('register.html')

# LOGIN
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        user = users.get(email)
        if user and user['password'] == password:
            session['email'] = email
            flash("Login berhasil!", "success")
            return redirect(url_for('katalog'))
        else:
            flash("Email atau password salah!", "danger")
            return redirect(url_for('login'))
    return render_template('login.html')

# LOGOUT
@app.route('/logout')
def logout():
    session.pop('email', None)
    flash("Anda telah logout.", "info")
    return redirect(url_for('login'))

# KATALOG PRODUK
@app.route('/katalog')
def katalog():
    if 'email' not in session:
        flash("Silakan login terlebih dahulu.", "warning")
        return redirect(url_for('login'))

    search = request.args.get('search', '').lower()
    filtered_products = [p for p in products if search in p['name'].lower()] if search else products
    return render_template('katalog.html', products=filtered_products)

# TAMBAH PRODUK
@app.route('/add_product', methods=['GET', 'POST'])
def add_product():
    if 'email' not in session:
        flash("Silakan login terlebih dahulu.", "warning")
        return redirect(url_for('login'))

    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        category = request.form.get('category', '').strip()
        price = request.form.get('price', '').strip()
        file = request.files.get('image')

        if not name:
            flash("Nama produk harus diisi!", "danger")
            return redirect(request.url)
        if not category:
            flash("Kategori harus dipilih!", "danger")
            return redirect(request.url)
        if not price:
            flash("Harga harus diisi!", "danger")
            return redirect(request.url)
        if not file or file.filename == '':
            flash("Gambar harus dipilih!", "danger")
            return redirect(request.url)

        try:
            price = int(price)
        except ValueError:
            flash("Harga harus berupa angka!", "danger")
            return redirect(request.url)

        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

            product_id = len(products) + 1
            products.append({
                "id": product_id,
                "name": name,
                "category": category,
                "price": price,
                "image": filename
            })
            flash("Produk berhasil ditambahkan!", "success")
            return redirect(url_for('katalog'))
        else:
            flash("File gambar tidak valid!", "danger")
            return redirect(request.url)

    return render_template('add_product.html')

# ADD TO CART
@app.route('/add_to_cart/<int:product_id>')
def add_to_cart(product_id):
    if 'email' not in session:
        flash("Silakan login terlebih dahulu.", "warning")
        return redirect(url_for('login'))

    cart = get_cart()
    key = str(product_id)
    if key in cart:
        cart[key] += 1
    else:
        cart[key] = 1
    save_cart(cart)
    flash("Produk berhasil dimasukkan ke keranjang.", "success")
    return redirect(url_for('cart'))

# REMOVE FROM CART
@app.route('/remove_from_cart/<int:product_id>')
def remove_from_cart(product_id):
    if 'email' not in session:
        flash("Silakan login terlebih dahulu.", "warning")
        return redirect(url_for('login'))

    cart = get_cart()
    key = str(product_id)
    if key in cart:
        del cart[key]
        save_cart(cart)
        flash("Produk berhasil dihapus dari keranjang.", "success")
    else:
        flash("Produk tidak ditemukan di keranjang.", "warning")

    return redirect(url_for('cart'))

# INCREASE QUANTITY
@app.route('/increase_quantity/<int:product_id>')
def increase_quantity(product_id):
    if 'email' not in session:
        flash("Silakan login terlebih dahulu.", "warning")
        return redirect(url_for('login'))

    cart = get_cart()
    key = str(product_id)
    if key in cart:
        cart[key] += 1
        save_cart(cart)
    return redirect(url_for('cart'))

# DECREASE QUANTITY
@app.route('/decrease_quantity/<int:product_id>')
def decrease_quantity(product_id):
    if 'email' not in session:
        flash("Silakan login terlebih dahulu.", "warning")
        return redirect(url_for('login'))

    cart = get_cart()
    key = str(product_id)
    if key in cart:
        if cart[key] > 1:
            cart[key] -= 1
        else:
            del cart[key]
        save_cart(cart)
    return redirect(url_for('cart'))

# HALAMAN KERANJANG
@app.route('/cart')
def cart():
    if 'email' not in session:
        flash("Silakan login terlebih dahulu.", "warning")
        return redirect(url_for('login'))

    cart = get_cart()
    cart_items = []
    total_price = 0

    for product_id_str, quantity in cart.items():
        try:
            product_id = int(product_id_str)
        except ValueError:
            continue

        product = next((p for p in products if p['id'] == product_id), None)
        if product:
            item_total = product['price'] * quantity
            cart_items.append({
                'product': product,
                'quantity': quantity,
                'item_total': item_total
            })
            total_price += item_total

    if cart_items:
        prices = [item['product']['price'] for item in cart_items]
        price_min = min(prices)
        price_max = max(prices)
    else:
        price_min = price_max = 0

    return render_template('cart.html', cart_items=cart_items, price_min=price_min, price_max=price_max, total_price=total_price)

# CHECKOUT / PEMBAYARAN (update agar simpan pesanan)
@app.route('/checkout', methods=['POST'])
def checkout():
    if 'email' not in session:
        flash("Silakan login terlebih dahulu.", "warning")
        return redirect(url_for('login'))

    payment_method = request.form.get('payment_method')
    if not payment_method or payment_method == '':
        flash("Silakan pilih metode pembayaran.", "danger")
        return redirect(url_for('cart'))

    cart = get_cart()
    if not cart:
        flash("Keranjang Anda kosong.", "warning")
        return redirect(url_for('cart'))

    user_email = session['email']

    # Ambil detail produk yang dipesan
    order_items = []
    for product_id_str, quantity in cart.items():
        product = next((p for p in products if p['id'] == int(product_id_str)), None)
        if product:
            order_items.append({
                "product": product,
                "quantity": quantity,
                "item_total": product['price'] * quantity
            })

    # Simpan order ke session user
    if 'orders' not in session:
        session['orders'] = {}
    orders = session['orders']
    if user_email in orders:
        orders[user_email].extend(order_items)  # tambah pesanan baru di atas yg lama
    else:
        orders[user_email] = order_items
    session['orders'] = orders

    session['cart'] = {}  # kosongkan keranjang

    flash(f"Pembayaran berhasil menggunakan metode {payment_method.replace('_', ' ').title()}. Terima kasih sudah berbelanja!", "success")
    return redirect(url_for('checkout_success'))

# HALAMAN SUKSES CHECKOUT dengan tombol Pesanan Saya
@app.route('/checkout_success')
def checkout_success():
    if 'email' not in session:
        flash("Silakan login terlebih dahulu.", "warning")
        return redirect(url_for('login'))
    return render_template('checkout_success.html')

# HALAMAN PESANAN SAYA - menampilkan produk yang sudah di-checkout user
@app.route('/my_orders')
def my_orders():
    if 'email' not in session:
        flash("Silakan login terlebih dahulu.", "warning")
        return redirect(url_for('login'))
    user_email = session['email']
    orders = session.get('orders', {})
    user_orders = orders.get(user_email, [])

    return render_template('my_orders.html', orders=user_orders)

# BUY NOW (simulasi)
@app.route('/buy_now/<int:product_id>')
def buy_now(product_id):
    if 'email' not in session:
        flash("Silakan login terlebih dahulu.", "warning")
        return redirect(url_for('login'))

    flash(f"Produk dengan ID {product_id} telah dibeli. Terima kasih!", "success")
    return redirect(url_for('katalog'))

if __name__ == '__main__':
    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])
    app.run(debug=True)